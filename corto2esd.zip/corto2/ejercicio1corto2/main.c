#include <stdio.h>
#include <string.h>

int tam;
char convertir[100];
char bin[100];

int decimal(int p){
    if( p == tam)
    return 0;

    int x=0;
    if (bin[p] ==  '1') x =1;
    else x =0 ;
    return (x << p) + decimal (p + 1);


}

int main (void){
    printf("Ingrese el tamaño: ");
    scanf("%d", &tam);

    printf("Ingrese el numero binario: ");
    scanf("%s", convertir);

    for (int i = 0; i < tam; i++){
        bin[i] = convertir[tam - 1 - i];

    }

    int resultado = decimal(0);
    printf("Decimal: %d\n", resultado);

}


