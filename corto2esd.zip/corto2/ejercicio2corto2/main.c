#include <stdio.h>
#include <stdlib.h>

void cambiar(int *a, int *b){
    *a=*a+*b;
    *b=*a-*b;
    *a=*a-*b;

}

int main() {

    int a= 24;
    int b=27;
    cambiar(&a, &b);

    printf("El valor de A es: %d\n", a);
    printf("El valor de B es: %d\n", b);

    return 0;
}